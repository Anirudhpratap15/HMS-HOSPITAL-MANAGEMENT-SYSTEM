package com.coforge.hospital.bean;
/**
 * 
 * @author Aayush Gupta
 *
 */
public class Ward {

	private int wid;
	private String wardName;
	private Patient patient;
	private Doctor doctor;
	public Ward(int wid, String wardName, Patient patient, Doctor doctor) {
		super();
		this.wid = wid;
		this.wardName = wardName;
		this.patient = patient;
		this.doctor = doctor;
	}
	public int getWid() {
		return wid;
	}
	public void setWid(int wid) {
		this.wid = wid;
	}
	public String getWardName() {
		return wardName;
	}
	public void setWardName(String wardName) {
		this.wardName = wardName;
	}
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	
	
	
}
