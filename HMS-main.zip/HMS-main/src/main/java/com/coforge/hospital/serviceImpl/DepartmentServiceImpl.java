package com.coforge.hospital.serviceImpl;

import java.sql.SQLException;

import com.coforge.hospital.bean.Department;
import com.coforge.hospital.daoImpl.DepartmentDaoImpl;
import com.coforge.hospital.service.DepartmentService;
/**
 * 
 * @author Ayush Gupta
 *
 */
public class DepartmentServiceImpl implements DepartmentService{

	private DepartmentDaoImpl departmentImpl;
	
	public DepartmentServiceImpl(){
		departmentImpl = new DepartmentDaoImpl();
	}

	public void deleteDepartment() throws SQLException {
		departmentImpl.deleteDepartment();
		
	}

	public void updateDepartment() throws SQLException {
		departmentImpl.updateDepartment();
	}

	public void display() {
		departmentImpl.display();
	}

	public Department getDept() {
		return departmentImpl.getDepartment();
	}

	public void addDepartment() throws SQLException {
		departmentImpl.addDepartment();
		
	}

}
