package com.coforge.hospital.bean;
/**
 * 
 * @author Aayush Gupta
 *
 */
public class Doctor {

	private int doctorId;
	private String doctorName;
	private String doctorAddress;
	private long doctorPhoneNO;
	private Department department;
	private Specialization sepcialization;
	
	public Doctor() {}

	public Doctor(int doctorId, String doctorName, String doctorAddress, long doctorPhoneNO, Department department,
			Specialization sepcialization) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorAddress = doctorAddress;
		this.doctorPhoneNO = doctorPhoneNO;
		this.department = department;
		this.sepcialization = sepcialization;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getDoctorAddress() {
		return doctorAddress;
	}

	public void setDoctorAddress(String doctorAddress) {
		this.doctorAddress = doctorAddress;
	}

	public long getDoctorPhoneNO() {
		return doctorPhoneNO;
	}

	public void setDoctorPhoneNO(long doctorPhoneNO) {
		this.doctorPhoneNO = doctorPhoneNO;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public Specialization getSepcialization() {
		return sepcialization;
	}

	public void setSepcialization(Specialization sepcialization) {
		this.sepcialization = sepcialization;
	}


}
