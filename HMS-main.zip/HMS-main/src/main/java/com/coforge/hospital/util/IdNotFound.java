package com.coforge.hospital.util;

@SuppressWarnings("serial")
public class IdNotFound extends Exception{
	public IdNotFound() {
		System.out.println("----------------- User define -----------------");
	}
	
	public String toString() {
		return "This ID is not in our system";
	}
}
