package com.coforge.hospital.dao;

import java.sql.SQLException;
import java.util.List;

import com.coforge.hospital.bean.Medicos;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;


public interface MedicosDao {
	
	public void addMed(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException;
	public void updateMed(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException;
	public void deleteMed() throws SQLException;
	
	public List<Medicos> retrieveMedicos();
	
	public void display();
	
	public Medicos getMedicos();

	}


