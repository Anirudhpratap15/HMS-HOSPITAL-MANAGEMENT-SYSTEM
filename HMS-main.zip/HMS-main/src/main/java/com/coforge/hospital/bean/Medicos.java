package com.coforge.hospital.bean;

/**
 * 
 * @author Anirudh
 *
 */
public class Medicos {

	private int mId;
	private String mRecord;
	private String date;

	private Doctor doctor;
	private Patient patient;

	public Medicos(int mId, String mRecord, String date, Doctor doctor, Patient patient) {
		super();
		this.mId = mId;
		this.mRecord = mRecord;
		this.date = date;
		this.doctor = doctor;
		this.patient = patient;
	}

	public int getmId() {
		return mId;
	}

	public void setmId(int mId) {
		this.mId = mId;
	}

	public String getmRecord() {
		return mRecord;
	}

	public void setmRecord(String mRecord) {
		this.mRecord = mRecord;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	
}
