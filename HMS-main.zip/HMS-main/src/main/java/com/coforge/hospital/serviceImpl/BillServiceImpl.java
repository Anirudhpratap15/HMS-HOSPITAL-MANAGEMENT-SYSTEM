package com.coforge.hospital.serviceImpl;

import java.sql.SQLException;

import com.coforge.hospital.bean.Bill;
import com.coforge.hospital.daoImpl.BillDaoImpl;
import com.coforge.hospital.service.BillService;

public class BillServiceImpl implements BillService{

	private BillDaoImpl billDaoImpl = new BillDaoImpl();

	public void display() {
		billDaoImpl.display();
	}

	public void add(InsuranceServiceImpl iService, PatientServiceImpl pService) throws SQLException {
		billDaoImpl.generateBill(iService, pService);
	}

	public void update(InsuranceServiceImpl iService, PatientServiceImpl pService) throws SQLException {
		billDaoImpl.updateBill(iService, pService);
	}

	public void delete() throws SQLException {
		billDaoImpl.deleteBill();
	}

	public Bill getBill() {
		return billDaoImpl.getBill();
	}

}
