package com.coforge.hospital.service;

import java.sql.SQLException;

import com.coforge.hospital.bean.Patient;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;
import com.coforge.hospital.serviceImpl.TestServiceImpl;

public interface PatientService {

	public void display();

	public void add(DoctorServiceImpl dService, TestServiceImpl tService) throws SQLException;

	public void update(DoctorServiceImpl dService, TestServiceImpl tService) throws SQLException;

	public void delete() throws SQLException;
	
	public Patient getPatient();
}
