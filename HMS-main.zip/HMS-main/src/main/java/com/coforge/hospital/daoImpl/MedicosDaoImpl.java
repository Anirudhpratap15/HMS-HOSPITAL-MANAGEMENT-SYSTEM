package com.coforge.hospital.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.coforge.hospital.bean.Medicos;
import com.coforge.hospital.dao.MedicosDao;
import com.coforge.hospital.database.Database;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;
import com.coforge.hospital.util.GetCurrentDate;
import com.coforge.hospital.util.IdNotFound;

public class MedicosDaoImpl implements MedicosDao {

	static private List<Medicos> medicos = new ArrayList<Medicos>();
	private Scanner sc = new Scanner(System.in);

	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	private final String addData = "INSERT INTO medicos VALUES(?,?,?,?,?,?)";
	private final String retriveData = "SELECT * FROM medicos WHERE isDeleted = false";
	private final String updateData = "UPDATE medicos SET Mrecord = ?, Mdate = ?,Did = ? , pid = ? WHERE Mid = ?";
	private final String deleteData = "UPDATE medicos SET isDeleted = true WHERE Mid = ?";
	
	public MedicosDaoImpl() {
		medicos = retrieveMedicos();
	}
	
	public void addMed(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(addData);

			System.out.print("Enter MEdicos ID : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			sc.nextLine();
			System.out.print("Enter Details : ");
			String deta = sc.nextLine();
			pst.setString(2, deta);

			String date = GetCurrentDate.getDateAndTime();
			pst.setString(3, date);

			pst.setInt(4, dService.getDoctor().getDoctorId());
			pst.setInt(5, pService.getPatient().getPid());
			pst.setBoolean(6, false);

			pst.executeUpdate();

			System.out.println("======================\n" + "Medicos " + id + " Saved\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void updateMed(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(updateData);

			System.out.print("Enter MEdicos ID : ");
			int id = sc.nextInt();
			pst.setInt(5, id);

			sc.nextLine();
			System.out.print("Enter Details : ");
			String deta = sc.nextLine();
			pst.setString(1, deta);

			String date = GetCurrentDate.getDateAndTime();
			pst.setString(2, date);

			pst.setInt(3, dService.getDoctor().getDoctorId());
			pst.setInt(4, pService.getPatient().getPid());

			pst.executeUpdate();

			System.out.println("======================\n" + "Medicos " + id + " updated\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void deleteMed() throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(deleteData);

			System.out.print("Enter Medicos ID : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			pst.executeUpdate();

			System.out.println("======================\n" + "Medicos " + id + " deleted\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<Medicos> retrieveMedicos() {
		List<Medicos> list = new ArrayList<Medicos>();
		try {
			con = Database.connect();
			pst = con.prepareStatement(retriveData);
			rs = pst.executeQuery();

			while (rs.next()) {
				list.add(new Medicos(rs.getInt(1), rs.getString(2), rs.getString(3),
						DoctorDaoImpl.getDoctor(rs.getInt(4)), PatientDaoImpl.getPatient(rs.getInt(5))));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public void display() {
		medicos = retrieveMedicos();
		System.out.println("--------------------------------------------------------------");
		for (Medicos m : medicos) {
			System.out.println("Medicos ID : " + m.getmId());
			System.out.println("Medicos Data : " + m.getmRecord());
			System.out.println("Medicos Date : " + m.getDate());
			System.out.println("Doctor : " + m.getDoctor().getDoctorId() + " " + m.getDoctor().getDoctorName());
			System.out.println("Patient : " + m.getPatient().getPid() + " " + m.getPatient().getpName());
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		}
		System.out.println("--------------------------------------------------------------");

	}
	
	public Medicos getMedicos() {
		boolean findIt = true;
		do {
			int flag = 0;
			System.out.print("Enter Department ID : ");
			int id = sc.nextInt();
			for (Medicos d : medicos) {
				if (d.getmId() == id) {
					flag = 1;
					findIt = false;
					return d;
				}
			}
			try {
				if (flag == 0) {
					throw new IdNotFound();
				}
			} catch (IdNotFound e) {
				System.out.println(e.toString());
			}
		} while (findIt);
		return null;
	}

	public static Medicos getMedicos(int id) {
		for(Medicos m : medicos) {
			if(m.getmId() == id)
				return m;
		}
		return null;
	}
	
}
