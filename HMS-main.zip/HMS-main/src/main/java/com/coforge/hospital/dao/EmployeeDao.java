package com.coforge.hospital.dao;

import java.sql.SQLException;
import java.util.List;

import com.coforge.hospital.bean.Employee;
import com.coforge.hospital.serviceImpl.DepartmentServiceImpl;

/**
 * 
 * @author Shipra
 *
 */

public interface EmployeeDao {
	
	public void addEmployee(DepartmentServiceImpl dService) throws SQLException;
	public List<Employee> retrieveEmployee();
	public void update(DepartmentServiceImpl dService) throws SQLException;
	public void delete() throws SQLException;
	
	public void display();
	
	public Employee getEmployee();


}

