package com.coforge.hospital.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.coforge.hospital.bean.Department;
import com.coforge.hospital.dao.DepartmentDao;
import com.coforge.hospital.database.Database;
import com.coforge.hospital.util.IdNotFound;

/**
 * 
 * @author Ayush Gupta
 *
 */

public class DepartmentDaoImpl implements DepartmentDao {

	static private List<Department> departments = new ArrayList<Department>();
	private Scanner sc = new Scanner(System.in);

	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	private final String addData = "INSERT INTO department(deptid, deptname) VALUES(?,?)";
	private final String retriveData = "SELECT * FROM department where isDeleted = false";
	private final String updateData = "UPDATE department SET deptname = ? WHERE deptid = ?";
	private final String deleteData = "UPDATE department SET isDeleted = true WHERE deptid = ?";

	public DepartmentDaoImpl() {
		departments = retrieveDept();
	}

	public void addDepartment() throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(addData);

			System.out.print("Enter Department id : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			sc.nextLine();
			System.out.print("Enter Department Name : ");
			String deptName = sc.nextLine();
			pst.setString(2, deptName);
//			pst.setBoolean(3, false); /*Set isDeleted False*/

			pst.executeUpdate();

			System.out.println("======================\n" + "Department " + id + " Saved\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Department getDepartment() {
		boolean findIt = true;
		do {
			int flag = 0;
			System.out.print("Enter Department ID : ");
			int id = sc.nextInt();
			for (Department d : departments) {
				if (d.getDeptId() == id) {
					flag = 1;
					findIt = false;
					return d;
				}
			}
			try {
				if (flag == 0) {
					throw new IdNotFound();
				}
			} catch (IdNotFound e) {
				System.out.println(e.toString());
			}
		} while (findIt);
		return null;
	}

	public void updateDepartment() throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(updateData);

			System.out.print("Enter Department ID   : ");
			int id = sc.nextInt();
			pst.setInt(2, id);

			sc.nextLine();
			System.out.print("Enter Department Name : ");
			String deptName = sc.nextLine();
			pst.setString(1, deptName);

			pst.executeUpdate();
			System.out
					.println("======================\n" + "Department " + id + " updated\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void deleteDepartment() throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(deleteData);

			System.out.print("Enter Department ID   : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			pst.executeUpdate();
			System.out
					.println("======================\n" + "Department " + id + " deleted\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public List<Department> retrieveDept() {
		List<Department> data = new ArrayList<Department>();
		try {
			con = Database.connect();
			pst = con.prepareStatement(retriveData);
			rs = pst.executeQuery();
			while (rs.next()) {
				data.add(new Department(rs.getInt(1), rs.getString(2)));
			}
		} catch (SQLException r) {
			r.printStackTrace();
		} finally {
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return data;
	}

	public void display() {
		departments = retrieveDept();
		System.out.println("--------------------------------------");
		for (Department d : departments) {
			System.out.println("Department ID     : " + d.getDeptId());
			System.out.println("Department Name   : " + d.getDeptName());
			System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		}
		System.out.println("--------------------------------------");
	}

	public static Department getDepartment(int id) {
		for (Department d : departments)
			if (d.getDeptId() == id)
				return d;
		return null;
	}

}
