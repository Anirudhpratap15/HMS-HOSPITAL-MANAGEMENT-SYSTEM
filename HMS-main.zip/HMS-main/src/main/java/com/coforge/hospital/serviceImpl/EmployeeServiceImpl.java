package com.coforge.hospital.serviceImpl;

import java.sql.SQLException;

import com.coforge.hospital.bean.Employee;
import com.coforge.hospital.daoImpl.EmployeeDaoImpl;
import com.coforge.hospital.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService{
	
	private EmployeeDaoImpl employeeImpl;
	
	public EmployeeServiceImpl()
	{
		employeeImpl=new EmployeeDaoImpl();
	}

	public void display() {
		employeeImpl.display();
	}

	public void add(DepartmentServiceImpl dService) throws SQLException {
		employeeImpl.addEmployee(dService);
	}

	public void update(DepartmentServiceImpl dService) throws SQLException {
		employeeImpl.update(dService);
	}

	public void delete() throws SQLException {
		employeeImpl.delete();
	}

	public Employee getEmployee() {
		return employeeImpl.getEmployee();
	}


}
