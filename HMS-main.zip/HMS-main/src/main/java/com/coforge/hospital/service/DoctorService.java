package com.coforge.hospital.service;

import java.sql.SQLException;

import com.coforge.hospital.bean.Doctor;
import com.coforge.hospital.serviceImpl.DepartmentServiceImpl;
import com.coforge.hospital.serviceImpl.SpecializationServiceImpl;

public interface DoctorService {
	public void add(DepartmentServiceImpl dService, SpecializationServiceImpl sImpl) throws SQLException;
	public void display();
	public void update(DepartmentServiceImpl dService, SpecializationServiceImpl sImpl) throws SQLException;
	public void delete() throws SQLException;
	
	public Doctor getDoctor();
}
