package com.coforge.hospital.serviceImpl;

import java.sql.SQLException;

import com.coforge.hospital.bean.Specialization;
import com.coforge.hospital.daoImpl.SpecializationDaoImpl;
import com.coforge.hospital.service.SpecializationService;

public class SpecializationServiceImpl implements SpecializationService {

	private SpecializationDaoImpl impl;
	
	public SpecializationServiceImpl() {
		impl = new SpecializationDaoImpl();
	}

	public void updateSepcialization() throws SQLException {
		impl.updateSepcialization();
		
	}

	public void deleteSepcialization() throws SQLException {
		impl.deleteSepcialization();
		
	}

	public void addSpecialzation() throws SQLException {
		impl.addSpecialzation();
		
	}

	public void display() {
		impl.display();
		
	}

	public Specialization getSpeciality() {
		return impl.getSpeciality();
	}

	
}
