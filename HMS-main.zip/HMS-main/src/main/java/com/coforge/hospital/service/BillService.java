package com.coforge.hospital.service;

import java.sql.SQLException;

import com.coforge.hospital.bean.Bill;
import com.coforge.hospital.serviceImpl.InsuranceServiceImpl;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;

public interface BillService {
public void display();
	
	public void add(InsuranceServiceImpl iService, PatientServiceImpl pService) throws SQLException;
	public void update(InsuranceServiceImpl iService, PatientServiceImpl pService) throws SQLException;
	public void delete() throws SQLException;
	
	public Bill getBill();
}
