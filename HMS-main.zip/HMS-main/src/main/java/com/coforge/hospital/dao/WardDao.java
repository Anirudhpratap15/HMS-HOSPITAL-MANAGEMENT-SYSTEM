package com.coforge.hospital.dao;

import java.sql.SQLException;
import java.util.List;

import com.coforge.hospital.bean.Ward;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;

public interface WardDao {
	
	public void addWard(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException;
	public void updateWard(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException;
	public void deleteWard() throws SQLException;
	public List<Ward> retrieveWard();
	
	public void display();
	
	public Ward getWard();
	
	
}
