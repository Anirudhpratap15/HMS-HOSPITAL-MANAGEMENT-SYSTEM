package com.coforge.hospital;

import java.sql.SQLException;
import java.util.Scanner;

import com.coforge.hospital.serviceImpl.BillServiceImpl;
import com.coforge.hospital.serviceImpl.DepartmentServiceImpl;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;
import com.coforge.hospital.serviceImpl.EmployeeServiceImpl;
import com.coforge.hospital.serviceImpl.InsuranceServiceImpl;
import com.coforge.hospital.serviceImpl.MedicosServiceImpl;
import com.coforge.hospital.serviceImpl.OperationServiceImpl;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;
import com.coforge.hospital.serviceImpl.SpecializationServiceImpl;
import com.coforge.hospital.serviceImpl.TestServiceImpl;
import com.coforge.hospital.serviceImpl.WardServiceImpl;

public class App {
	
	public static void main(String[] args) throws SQLException {
		
		Scanner sc = new Scanner(System.in);

		DepartmentServiceImpl deptServiceImpl = new DepartmentServiceImpl();
		SpecializationServiceImpl specServiceImpl = new SpecializationServiceImpl();
		DoctorServiceImpl doctorServiceImpl = new DoctorServiceImpl();
		EmployeeServiceImpl empServiceImpl = new EmployeeServiceImpl();
		TestServiceImpl testServiceImpl = new TestServiceImpl();
		PatientServiceImpl patientServiceImpl = new PatientServiceImpl();
		InsuranceServiceImpl insuranceServiceImpl = new InsuranceServiceImpl();
		BillServiceImpl billServiceImpl = new BillServiceImpl();
		WardServiceImpl wardServiceImpl = new WardServiceImpl();
		OperationServiceImpl operationServiceImpl = new OperationServiceImpl();
		MedicosServiceImpl medicosServiceImpl = new MedicosServiceImpl();
		
		boolean loop = true;

		do {
			System.out.println("for Department     Press 1\n" + "for Specialization Press 2\n"
					+ "for Doctor ------- Press 3\n" + "for Employee ----- Press 4\n" + "for Test --------- Press 5\n"
					+ "for Patient ------ Press 6\n" + "for Ward --------- Press 7\n" + "for Insurance ---- Press 8\n"
					+ "for Bill --------- Press 9\n" + "for Medicos ------ Press 10\n" + "for Operation ---- Press 11\n"
					+ "Quit ------------- Press 0");
			switch (sc.nextInt()) {
			case 1:

				boolean deptLoop = true;
				do {
					System.out.println("CREATE-----> 1\n" + "RETRIEVE --> 2\n" + "DELETE ----> 3\n" + "UPDATE ----> 4\n"
							+ "QUIT ----- > 5");

					switch (sc.nextInt()) {
					case 1:
						deptServiceImpl.addDepartment();
						break;
					case 2:
						System.out.println("Retrieving...");
						deptServiceImpl.display();
						break;
					case 3:
						deptServiceImpl.deleteDepartment();
						break;
					case 4:
						deptServiceImpl.updateDepartment();
						break;
					case 5:
						deptLoop = false;
						break;
					}
				} while (deptLoop);
				break;
			case 2:

				boolean specLoop = true;
				do {
					System.out.println("CREATE-----> 1\n" + "RETRIEVE --> 2\n" + "DELETE ----> 3\n" + "UPDATE ----> 4\n"
							+ "QUIT ----- > 5");
					switch (sc.nextInt()) {
					case 1:
						specServiceImpl.addSpecialzation();
						break;
					case 2:
						System.out.println("Retrieving...");
						specServiceImpl.display();
						break;
					case 3:
						specServiceImpl.deleteSepcialization();
						break;
					case 4:
						specServiceImpl.updateSepcialization();
						break;
					case 5:
						specLoop = false;
						break;
					}
				} while (specLoop);
				break;
			case 3:

				boolean docLoop = true;
				do {
					System.out.println("CREATE-----> 1\n" + "RETRIEVE --> 2\n" + "DELETE ----> 3\n" + "UPDATE ----> 4\n"
							+ "QUIT ----- > 5");
					switch (sc.nextInt()) {
					case 1:
						doctorServiceImpl.add(deptServiceImpl, specServiceImpl);
						break;
					case 2:
						System.out.println("Retrieving...");
						doctorServiceImpl.display();
						break;
					case 3:
						doctorServiceImpl.delete();
						break;
					case 4:
						doctorServiceImpl.update(deptServiceImpl, specServiceImpl);
						break;
					case 5:
						docLoop = false;
						break;
					}
				} while (docLoop);
				break;
			case 4:
				boolean empLoop = true;
				do {
					System.out.println("CREATE-----> 1\n" + "RETRIEVE --> 2\n" + "DELETE ----> 3\n" + "UPDATE ----> 4\n"
							+ "QUIT ----- > 5");

					switch (sc.nextInt()) {
					case 1:
						empServiceImpl.add(deptServiceImpl);
						break;
					case 2:
						System.out.println("Retrieving...");
						empServiceImpl.display();
						break;
					case 3:
						empServiceImpl.delete();
						break;
					case 4:
						empServiceImpl.update(deptServiceImpl);
						break;
					case 5:
						empLoop = false;
						break;
					}
				} while (empLoop);

				break;
			case 5:
				boolean testLoop = true;
				do {
					System.out.println("CREATE-----> 1\n" + "RETRIEVE --> 2\n" + "DELETE ----> 3\n" + "UPDATE ----> 4\n"
							+ "QUIT ----- > 5");
					switch (sc.nextInt()) {
					case 1:
						testServiceImpl.add(doctorServiceImpl);
						break;
					case 2:
						System.out.println("Retrieving...");
						testServiceImpl.display();
						break;
					case 3:
						testServiceImpl.delete();
						break;
					case 4:
						testServiceImpl.update(doctorServiceImpl);
						break;
					case 5:
						testLoop = false;
						break;
					}
				} while (testLoop);
				break;
			case 6:
				boolean patientLoop = true;
				do {
					System.out.println("CREATE-----> 1\n" + "RETRIEVE --> 2\n" + "DELETE ----> 3\n" + "UPDATE ----> 4\n"
							+ "QUIT ----- > 5");

					switch (sc.nextInt()) {
					case 1:
						patientServiceImpl.add(doctorServiceImpl, testServiceImpl);
						break;
					case 2:
						System.out.println("Retrieving...");
						patientServiceImpl.display();
						break;
					case 3:
						patientServiceImpl.delete();
						break;
					case 4:
						patientServiceImpl.update(doctorServiceImpl, testServiceImpl);
						break;
					case 5:
						patientLoop = false;
						break;
					}
				} while (patientLoop);
				break;
			case 7:
				boolean wardLoop = true;
				do {
					System.out.println("CREATE-----> 1\n" + "RETRIEVE --> 2\n" + "DELETE ----> 3\n" + "UPDATE ----> 4\n"
							+ "QUIT ----- > 5");

					switch (sc.nextInt()) {
					case 1:
						wardServiceImpl.add(doctorServiceImpl,patientServiceImpl);
						break;
					case 2:
						System.out.println("Retrieving...");
						wardServiceImpl.display();
						break;
					case 3:
						wardServiceImpl.delete();
						break;
					case 4:
						wardServiceImpl.update(doctorServiceImpl,patientServiceImpl);
						break;
					case 5:
						wardLoop = false;
						break;
					}
				} while (wardLoop);
				break;
			case 8:
				boolean inLoop = true;
				do {
					System.out.println("CREATE-----> 1\n" + "RETRIEVE --> 2\n" + "DELETE ----> 3\n" + "UPDATE ----> 4\n"
							+ "QUIT ----- > 5");

					switch (sc.nextInt()) {
					case 1:
						insuranceServiceImpl.add(patientServiceImpl);
						break;
					case 2:
						System.out.println("Retrieving...");
						insuranceServiceImpl.display();
						break;
					case 3:
						insuranceServiceImpl.delete();
						break;
					case 4:
						insuranceServiceImpl.update(patientServiceImpl);
						break;
					case 5:
						inLoop = false;
						break;
					}
				} while (inLoop);

				break;
			case 9:
				boolean billLoop = true;
				do {
					System.out.println("CREATE-----> 1\n" + "RETRIEVE --> 2\n" + "DELETE ----> 3\n" + "UPDATE ----> 4\n"
							+ "QUIT ----- > 5");

					switch (sc.nextInt()) {
					case 1:
						billServiceImpl.add(insuranceServiceImpl, patientServiceImpl);
						break;
					case 2:
						System.out.println("Retrieving...");
						billServiceImpl.display();
						break;
					case 3:
						billServiceImpl.delete();
						break;
					case 4:
						billServiceImpl.update(insuranceServiceImpl, patientServiceImpl);
						break;
					case 5:
						billLoop = false;
						break;
					}
				} while (billLoop);
				break;
			case 10:
				boolean medLoop = true;
				do {
					System.out.println("CREATE-----> 1\n" + "RETRIEVE --> 2\n" + "DELETE ----> 3\n" + "UPDATE ----> 4\n"
							+ "QUIT ----- > 5");

					switch (sc.nextInt()) {
					case 1:
						medicosServiceImpl.add(doctorServiceImpl, patientServiceImpl);
						break;
					case 2:
						System.out.println("Retrieving...");
						medicosServiceImpl.display();
						break;
					case 3:
						medicosServiceImpl.delete();
						break;
					case 4:
						medicosServiceImpl.update(doctorServiceImpl, patientServiceImpl);
						break;
					case 5:
						medLoop = false;
						break;
					}
				} while (medLoop);
				break;
			case 11:
				boolean opLoop = true;
				do {
					System.out.println("CREATE-----> 1\n" + "RETRIEVE --> 2\n" + "DELETE ----> 3\n" + "UPDATE ----> 4\n"
							+ "QUIT ----- > 5");

					switch (sc.nextInt()) {
					case 1:
						operationServiceImpl.add(doctorServiceImpl, patientServiceImpl);
						break;
					case 2:
						System.out.println("Retrieving...");
						operationServiceImpl.display();
						break;
					case 3:
						operationServiceImpl.delete();
						break;
					case 4:
						operationServiceImpl.update(doctorServiceImpl, patientServiceImpl);
						break;
					case 5:
						opLoop = false;
						break;
					}
				} while (opLoop);
				break;
			case 0:
				loop = false;
				break;
			}
		} while (loop);
		sc.close();
	}
}
