package com.coforge.hospital.serviceImpl;

import java.sql.SQLException;

import com.coforge.hospital.bean.Insurance;
import com.coforge.hospital.daoImpl.InsuranceDaoImpl;
import com.coforge.hospital.service.InsuranceService;

public class InsuranceServiceImpl implements InsuranceService{
	
	private InsuranceDaoImpl daoImpl = new InsuranceDaoImpl();

	public void add(PatientServiceImpl pService) throws SQLException {
		daoImpl.addInsurance(pService);
	}

	public void update(PatientServiceImpl pService) throws SQLException {
		daoImpl.updateInsurance(pService);
	}

	public void delete() throws SQLException {
		daoImpl.deleteInsurance();
	}

	public void display() {
		daoImpl.display();
	}

	public Insurance getInsurance() {
		return daoImpl.getInsurance();
	}
	
	
}
