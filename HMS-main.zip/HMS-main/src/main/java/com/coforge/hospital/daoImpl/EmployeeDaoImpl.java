package com.coforge.hospital.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.coforge.hospital.bean.Department;
import com.coforge.hospital.bean.Employee;
import com.coforge.hospital.dao.EmployeeDao;
import com.coforge.hospital.database.Database;
import com.coforge.hospital.serviceImpl.DepartmentServiceImpl;
import com.coforge.hospital.util.IdNotFound;

public class EmployeeDaoImpl implements EmployeeDao {
	
	static private List<Employee> emps = new ArrayList<Employee>();
	private Scanner sc = new Scanner(System.in);

	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	private final String addData = "INSERT INTO employee VALUES(?,?,?,?,?,?)";
	private final String retriveData = "SELECT * FROM employee WHERE isDeleted = false";
	private final String updateData = "UPDATE employee SET EmpName = ?, EmpMobileNo = ?, EmpAddress = ?, Deptid = ? WHERE Empid = ?";
	private final String deleteData = "UPDATE employee SET isDeleted = true WHERE Empid = ?";
	
	public EmployeeDaoImpl() {
		emps = retrieveEmployee();
	}

	public void addEmployee(DepartmentServiceImpl dService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(addData);


			System.out.print("Employee Id : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			sc.nextLine();
			System.out.print("Employee Name : ");
			String name = sc.nextLine();
			pst.setString(2, name);

			System.out.print("Employee address : ");
			String address = sc.nextLine();
			pst.setString(4, address);

			System.out.print("Employee phone no : ");
			long mNo = sc.nextLong();
			pst.setLong(3, mNo);

			Department dept = dService.getDept();
			pst.setInt(5, dept.getDeptId());
			
			pst.setBoolean(6, false); /*SET isDelete = false*/

			pst.executeUpdate();

			System.out.println("======================\n" + "Employee " + id + " Saved\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void update(DepartmentServiceImpl dService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(updateData);
			
			System.out.print("Employee Id : ");
			int id = sc.nextInt();
			pst.setInt(5, id);

			sc.nextLine();
			System.out.print("Employee Name : ");
			String name = sc.nextLine();
			pst.setString(1, name);
			
			System.out.print("Employee address : ");
			String address = sc.nextLine();
			pst.setString(3, address);
			
			System.out.print("Employee phone no : ");
			long mNo = sc.nextLong();
			pst.setLong(2, mNo);

			Department dept = dService.getDept();
			pst.setInt(4, dept.getDeptId());

			pst.executeUpdate();
			
			System.out.println("======================\n" + "Employee " + id + " Update\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	public void delete() throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(deleteData);
		
			System.out.print("Enter Emp ID : ");
			int id = sc.nextInt();
			pst.setInt(1, id);
			
			pst.executeUpdate();
			
			System.out.println("======================\n" + "Employee " + id + " Deleted\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public List<Employee> retrieveEmployee() {
		List<Employee> empList = new ArrayList<Employee>();

		try {
			con = Database.connect();
			pst = con.prepareStatement(retriveData);
			rs = pst.executeQuery();

			while (rs.next()) {
				Employee emp = new Employee();
				emp.setEmpId(rs.getInt(1));
				emp.setEmpName(rs.getString(2));
				emp.setEmpMobileNo(rs.getLong(3));
				emp.setEmpAdd(rs.getString(4));
				emp.setDepartment(DepartmentDaoImpl.getDepartment(rs.getInt(5)));

				empList.add(emp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return empList;
	}
	
	public void display() {
		emps = retrieveEmployee();
		System.out.println("-----------------------------------------------");
		for (Employee e : emps) {
			System.out.println("Employee ID 		: " + e.getEmpId());
			System.out.println("Employee Name 		: " + e.getEmpName());
			System.out.println("Employee PNO	 	: " + e.getEmpMobileNo());
			System.out.println("Employee Address 	: " + e.getEmpAdd());
			System.out.println("Employee Department 	: " + e.getDepartment().getDeptName());
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
		}
		System.out.println("-----------------------------------------------");
	}

	public Employee getEmployee() {
		boolean findIt = true;
		do {
			int flag = 0;
			System.out.print("Enter Employee ID : ");
			int id = sc.nextInt();
			for (Employee e : emps) {
				if (e.getEmpId() == id) {
					flag = 1;
					findIt = false;
					return e;
				}
			}
			try {
				if (flag == 0) {
					throw new IdNotFound();
				}
			} catch (IdNotFound e) {
				System.out.println(e.toString());
			}
		} while (findIt);
		return null;
	}

	
		

}
