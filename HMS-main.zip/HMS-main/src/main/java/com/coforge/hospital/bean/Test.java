package com.coforge.hospital.bean;

/**
 * 
 * @author Shipra
 *
 */
public class Test {
	private int tid;
	private String tName;
	private String tDate;
	private Doctor doctor;

	public Test(int tid, String tName, String tDate, Doctor doctor) {
		super();
		this.tid = tid;
		this.tName = tName;
		this.tDate = tDate;
		this.doctor = doctor;
	}

	public Test() {
		super();
	}

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String gettName() {
		return tName;
	}

	public void settName(String tName) {
		this.tName = tName;
	}

	public String gettDate() {
		return tDate;
	}

	public void settDate(String tDate) {
		this.tDate = tDate;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	@Override
	public String toString() {
		return "Test [tid=" + tid + ", tName=" + tName + ", tDate=" + tDate + ", doctor=" + doctor + "]";
	}
}
