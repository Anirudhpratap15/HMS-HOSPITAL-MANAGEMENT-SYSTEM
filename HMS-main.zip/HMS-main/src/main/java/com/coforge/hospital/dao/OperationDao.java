package com.coforge.hospital.dao;


import java.sql.SQLException;
import java.util.List;

import com.coforge.hospital.bean.Operation;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;

public interface OperationDao {
	public void addOpertion(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException;
	public void updateOpertion(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException;
	public void deleteOpertion() throws SQLException;
	public List<Operation> retrieveOPerations();
	
	public void display();
	
	public Operation getOper();

}
