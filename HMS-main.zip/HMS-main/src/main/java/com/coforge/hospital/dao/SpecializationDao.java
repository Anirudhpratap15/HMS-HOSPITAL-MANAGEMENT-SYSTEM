package com.coforge.hospital.dao;

import java.sql.SQLException;
import java.util.List;

import com.coforge.hospital.bean.Specialization;

public interface SpecializationDao {

	public void updateSepcialization() throws SQLException;
	public void deleteSepcialization() throws SQLException;
	public void addSpecialzation() throws SQLException;
	public void display();
	public List<Specialization> retrieveSpec();
	
	
	public Specialization getSpeciality();
}
