package com.coforge.hospital.service;

import java.sql.SQLException;

import com.coforge.hospital.bean.Insurance;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;

public interface InsuranceService {

	public void add(PatientServiceImpl pService) throws SQLException;

	public void update(PatientServiceImpl pService) throws SQLException;

	public void delete() throws SQLException;

	public void display();
	
	public Insurance getInsurance();
}
