package com.coforge.hospital.dao;

import java.sql.SQLException;
import java.util.List;

import com.coforge.hospital.bean.Doctor;
import com.coforge.hospital.serviceImpl.DepartmentServiceImpl;
import com.coforge.hospital.serviceImpl.SpecializationServiceImpl;

/**
 * 
 * @author Ayush Kumar Gupta
 *
 */
public interface DoctorDao {

	public void addDoctor(DepartmentServiceImpl departmentService, SpecializationServiceImpl specializationService) throws SQLException;
	public void updateDoctor(DepartmentServiceImpl departmentService, SpecializationServiceImpl specializationService) throws SQLException;
	public void deleteDoctor() throws SQLException;
	public List<Doctor> retrieveDoctors();
	
	public void display();
	
	public Doctor getDoctor();
}
