package com.coforge.hospital.bean;
/**
 * 
 * @author Anirudh
 *
 */

public class Operation {

	private int oid;
	private String oName;
	
	private Patient patient;
	private Doctor doctor;
	
	public Operation(int oid, String oName, Patient patient, Doctor doctor) {
		super();
		this.oid = oid;
		this.oName = oName;
		this.patient = patient;
		this.doctor = doctor;
	}
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public String getoName() {
		return oName;
	}
	public void setoName(String oName) {
		this.oName = oName;
	}
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	
	
}
