package com.coforge.hospital.bean;

/**
 * 
 * @author Aayush Gupta
 *
 */

public class Specialization {

	private int specId;
	private String Speciality;

	public Specialization() {
		super();
	}

	public Specialization(int specId, String speciality) {
		super();
		this.specId = specId;
		Speciality = speciality;
	}

	public int getSpecId() {
		return specId;
	}

	public void setSpecId(int specId) {
		this.specId = specId;
	}

	public String getSpeciality() {
		return Speciality;
	}

	public void setSpeciality(String speciality) {
		Speciality = speciality;
	}

	@Override
	public String toString() {
		return "Sepcialization [specId=" + specId + ", Speciality=" + Speciality + "]";
	}

}
