package com.coforge.hospital.dao;

import java.sql.SQLException;
import java.util.List;

import com.coforge.hospital.bean.Insurance;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;


public interface InsuranceDao {
	
	public void addInsurance(PatientServiceImpl pService) throws SQLException;
	public void updateInsurance(PatientServiceImpl pService) throws SQLException;
	public void deleteInsurance() throws SQLException;
	public List<Insurance> retrieveInsurance();
	
	public void display();
	
	public Insurance getInsurance();
	

}
