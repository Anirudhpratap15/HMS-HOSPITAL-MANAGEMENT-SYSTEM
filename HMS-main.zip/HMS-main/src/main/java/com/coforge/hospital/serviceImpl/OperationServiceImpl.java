package com.coforge.hospital.serviceImpl;

import java.sql.SQLException;

import com.coforge.hospital.bean.Operation;
import com.coforge.hospital.daoImpl.OperationDaoImpl;
import com.coforge.hospital.service.OperationService;

public class OperationServiceImpl implements OperationService{

	private OperationDaoImpl impl = new OperationDaoImpl();

	public void add(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException {
		impl.addOpertion(dService, pService);
	}

	public void delete() throws SQLException {
		impl.deleteOpertion();
	}

	public void update(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException {
		impl.updateOpertion(dService, pService);
	}

	public void display() {
		impl.display();
	}

	public Operation getOperation() {
		return impl.getOper();
	}

}
