package com.coforge.hospital.bean;


/**
 * 
 * @author Shipra
 *
 */

public class Patient {
	private int pid;
	private String pName;
	private String pDob;
	private String pAdd;
	private long pMobileNo;
	
	private Doctor doc;
	private Test test;

	public Patient(int pid, String pName, String pDob, String pAdd, long pMobileNo, Doctor doc, Test test) {
		super();
		this.pid = pid;
		this.pName = pName;
		this.pDob = pDob;
		this.pAdd = pAdd;
		this.pMobileNo = pMobileNo;
		this.doc = doc;
		this.test = test;
	}
	public Patient() {
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getpDob() {
		return pDob;
	}
	public void setpDob(String pDob) {
		this.pDob = pDob;
	}
	public String getpAdd() {
		return pAdd;
	}
	public void setpAdd(String pAdd) {
		this.pAdd = pAdd;
	}
	public long getpMobileNo() {
		return pMobileNo;
	}
	public void setpMobileNo(long pMobileNo) {
		this.pMobileNo = pMobileNo;
	}
	public Doctor getDoc() {
		return doc;
	}
	public void setDoc(Doctor doc) {
		this.doc = doc;
	}
	public Test getTest() {
		return test;
	}
	public void setTest(Test test) {
		this.test = test;
	}
	
	
	
	
	
	
}
