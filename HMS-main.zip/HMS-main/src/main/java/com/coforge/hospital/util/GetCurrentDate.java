package com.coforge.hospital.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class GetCurrentDate {
	public static String getDateAndTime() {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
		Date date = new Date();
		return sdf.format(date);
	}
}
