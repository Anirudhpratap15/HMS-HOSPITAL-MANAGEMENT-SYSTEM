package com.coforge.hospital.dao;

import java.sql.SQLException;
import java.util.List;

import com.coforge.hospital.bean.Bill;
import com.coforge.hospital.serviceImpl.InsuranceServiceImpl;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;

public interface BillDao {
	
	public void generateBill(InsuranceServiceImpl iService, PatientServiceImpl pService) throws SQLException;
	public void updateBill(InsuranceServiceImpl iService, PatientServiceImpl pService) throws SQLException;
	public void deleteBill() throws SQLException;
	public List<Bill> retrieveBill();
	
	public void display();
	
	public Bill getBill();

}



