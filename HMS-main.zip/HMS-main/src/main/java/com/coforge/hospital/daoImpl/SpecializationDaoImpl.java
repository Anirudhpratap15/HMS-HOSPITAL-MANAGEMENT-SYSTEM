package com.coforge.hospital.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.coforge.hospital.bean.Specialization;
import com.coforge.hospital.dao.SpecializationDao;
import com.coforge.hospital.database.Database;
import com.coforge.hospital.util.IdNotFound;

public class SpecializationDaoImpl implements SpecializationDao{

	static private List<Specialization> specializations = new ArrayList<Specialization>();
	private Scanner sc = new Scanner(System.in);

	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	private final String addData = "INSERT INTO sepcialization(Specid, Speciality) VALUES(?,?)";
	private final String retrieveData = "SELECT * FROM sepcialization WHERE isDeleted = false";
	private final String updateData = "UPDATE sepcialization SET Speciality = ? WHERE Specid = ?";
	private final String deleteData = "UPDATE sepcialization SET isDeleted = true WHERE Specid = ?";
	
	public SpecializationDaoImpl(){
		specializations = retrieveSpec();
	}

	/**
	 * add speciality of doctor
	 */
	public void addSpecialzation() throws SQLException { 
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(addData);
			
			System.out.print("Enter Id : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			sc.nextLine();
			System.out.print("Enter Speciality : ");
			String deptName = sc.nextLine();
			pst.setString(2, deptName);
			
			pst.executeUpdate();

			System.out.println("======================\n" + "Department " + id + " Saved\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}


	public Specialization getSpeciality() {
		boolean findIt = true;
		do {
			int flag = 0;
			System.out.print("Enter specialization ID : ");
			int id = sc.nextInt();
			for (Specialization d : specializations) {
				if (d.getSpecId() == id) {
					flag = 1;
					findIt = false;
					return d;
				}
			}
			try {
				if (flag == 0) {
					throw new IdNotFound();
				}
			} catch (IdNotFound e) {
				System.out.println(e.toString());
			}
		} while (findIt);
		return null;
	}

	public void updateSepcialization() throws SQLException {
		
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(updateData);

			
			System.out.print("Enter Id : ");
			int id = sc.nextInt();
			pst.setInt(2, id);
			

			sc.nextLine();
			System.out.print("Enter Speciality : ");
			String deptName = sc.nextLine();
			pst.setString(1, deptName);
			

			pst.executeUpdate();

			System.out.println("======================\n" + "Department " + id + " Updated\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

	public void deleteSepcialization() throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(deleteData);

			System.out.print("Enter Id : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			pst.executeUpdate();

			System.out.println("======================\n" + "Department " + id + " Deleted\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

	

	public List<Specialization> retrieveSpec() {
		List<Specialization> data = new ArrayList<Specialization>();
		try {
			con = Database.connect();
			pst = con.prepareStatement(retrieveData);
			rs = pst.executeQuery();

			while (rs.next()) {
				data.add(new Specialization(rs.getInt(1), rs.getString(2)));
				
			}
		} catch (SQLException r) {
			r.printStackTrace();
		} finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return data;
	}

	public static Specialization getSpeciality(int id) {
		
		for (Specialization d : specializations)
			if (d.getSpecId() == id)
				return d;
		return null;
	}

	public void display() {
		specializations = retrieveSpec();
		System.out.println("--------------------------------------");
		for (Specialization d : specializations) {
			System.out.println("specialization ID     : " + d.getSpecId());
			System.out.println("specialization Name   : " + d.getSpeciality());
			System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		}
		System.out.println("--------------------------------------");
		
	}
}
