package com.coforge.hospital.serviceImpl;

import java.sql.SQLException;

import com.coforge.hospital.bean.Ward;
import com.coforge.hospital.daoImpl.WardDaoImpl;
import com.coforge.hospital.service.WardService;

public class WardServiceImpl implements WardService{

	private WardDaoImpl impl;

	public WardServiceImpl() {
		impl = new WardDaoImpl();
	}

	public void add(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException {
		impl.addWard(dService, pService);
	}

	public void delete() throws SQLException {
		impl.deleteWard();
	}

	public void update(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException {
		impl.updateWard(dService, pService);
	}

	public void display() {
		impl.display();
	}

	public Ward getWard() {
		return impl.getWard();
	}
}
