package com.coforge.hospital.serviceImpl;

import java.sql.SQLException;

import com.coforge.hospital.bean.Doctor;
import com.coforge.hospital.daoImpl.DoctorDaoImpl;
import com.coforge.hospital.service.DoctorService;

public class DoctorServiceImpl implements DoctorService{

	private DoctorDaoImpl doctorImpl;
	
	public DoctorServiceImpl() {
		doctorImpl = new DoctorDaoImpl();
	}

	public Doctor getDoctor() {
		return doctorImpl.getDoctor();
	}

	public void add(DepartmentServiceImpl dService, SpecializationServiceImpl sImpl) throws SQLException {
		doctorImpl.addDoctor(dService, sImpl);
		
	}

	public void display() {
		doctorImpl.display();
		
	}

	public void update(DepartmentServiceImpl dService, SpecializationServiceImpl sImpl) throws SQLException {
		doctorImpl.updateDoctor(dService, sImpl);
	}

	public void delete() throws SQLException {
		doctorImpl.deleteDoctor();
	}
	
	
}
