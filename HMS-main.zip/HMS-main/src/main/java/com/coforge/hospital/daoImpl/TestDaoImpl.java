package com.coforge.hospital.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.coforge.hospital.bean.Test;
import com.coforge.hospital.dao.TestDao;
import com.coforge.hospital.database.Database;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;
import com.coforge.hospital.util.GetCurrentDate;
import com.coforge.hospital.util.IdNotFound;

public class TestDaoImpl implements TestDao {
	
	static private List<Test> tests = new ArrayList<Test>();
	private Scanner sc = new Scanner(System.in);

	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	private final String addData = "INSERT INTO test VALUES(?,?,?,?,?)";
	private final String retriveData = "SELECT * FROM test WHERE isDeleted = false";
	private final String updateData = "UPDATE test SET Tname = ?, Tdate = ?, Did = ? WHERE Tid = ?";
	private final String deleteData = "UPDATE test SET isDeleted = true WHERE Tid = ?";


	public TestDaoImpl() {
		tests = retrieveTest();
	}

	public void doTest(DoctorServiceImpl dService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(addData);


			System.out.print("Enter Test Id : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			sc.nextLine();
			System.out.print("Enter Test Name : ");
			String name = sc.nextLine();
			pst.setString(2, name);

			String date = GetCurrentDate.getDateAndTime();
			pst.setString(3, date);

			pst.setInt(4, dService.getDoctor().getDoctorId());
			pst.setBoolean(5, false);

			pst.executeUpdate();

			System.out.println("======================\n" + "Test " + id + " Saved\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void update(DoctorServiceImpl dService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(updateData);

			System.out.print("Enter Test Id : ");
			int id = sc.nextInt();
			pst.setInt(4, id);

			sc.nextLine();
			System.out.print("Enter Test Name : ");
			String name = sc.nextLine();
			pst.setString(1, name);

			String date = GetCurrentDate.getDateAndTime();
			pst.setString(2, date);

			pst.setInt(3, dService.getDoctor().getDoctorId());

			pst.executeUpdate();

			System.out.println("======================\n" + "Test " + id + " Update\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void delete() throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(deleteData);

			System.out.print("Enter Test Id : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			pst.executeUpdate();

			System.out.println("======================\n" + "Test " + id + " Deleted\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public List<Test> retrieveTest() {
		List<Test> testList = new ArrayList<Test>();
		try {
			con = Database.connect();
			pst = con.prepareStatement(retriveData);
			
			rs = pst.executeQuery();
			
			while(rs.next()) {
				Test test = new Test();
				
				test.setTid(rs.getInt(1));
				test.settName(rs.getString(2));
				test.settDate(rs.getString(3));
				test.setDoctor(DoctorDaoImpl.getDoctor(rs.getInt(4)));
				
				testList.add(test);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return testList;
	}

	public void display() {
		tests = retrieveTest();
		System.out.println("-------------------------------------");
		for (Test test : tests) {
			System.out.println("Test ID 	: " + test.getTid());
			System.out.println("Test Name  	: " + test.gettName());
			System.out.println("Test Date 	: " + test.gettDate());
			System.out.println("Doctor ref 	: " + test.getDoctor().getDoctorName());
			System.out.println("++++++++++++++++++++++++++++++++++++++++");
		}
		System.out.println("-------------------------------------");
	}

	public Test getReport() {
		boolean findIt = true;
		do {
			int flag = 0;
			System.out.print("Enter Test ID : ");
			int id = sc.nextInt();
			for (Test t : tests) {
				if (t.getTid() == id) {
					flag = 1;
					findIt = false;
					return t;
				}
			}
			try {
				if (flag == 0) {
					throw new IdNotFound();
				}
			} catch (IdNotFound e) {
				System.out.println(e.toString());
			}
		} while (findIt);
		return null;
	}

	public static Test getReport(int id) {
		for(Test t : tests)
			if(t.getTid() == id)
				return t;
		return null;
	}
}
