package com.coforge.hospital.serviceImpl;

import java.sql.SQLException;

import com.coforge.hospital.bean.Test;
import com.coforge.hospital.daoImpl.TestDaoImpl;
import com.coforge.hospital.service.TestService;

public class TestServiceImpl implements TestService{
	
private TestDaoImpl testImpl;

	
	public TestServiceImpl() {
		testImpl = new TestDaoImpl();
	}


	public void add(DoctorServiceImpl dService) throws SQLException {
		testImpl.doTest(dService);
	}


	public void update(DoctorServiceImpl dService) throws SQLException {
		testImpl.update(dService);
	}


	public void delete() throws SQLException {
		testImpl.delete();
	}


	public Test getReport() {
		return testImpl.getReport();
	}


	public void display() {
		testImpl.display();
	}
}



