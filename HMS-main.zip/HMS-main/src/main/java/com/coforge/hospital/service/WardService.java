package com.coforge.hospital.service;

import java.sql.SQLException;

import com.coforge.hospital.bean.Ward;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;

public interface WardService {

	public void add(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException;
	public void delete() throws SQLException;
	public void update(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException;
	public void display();
	
	public Ward getWard();
}
