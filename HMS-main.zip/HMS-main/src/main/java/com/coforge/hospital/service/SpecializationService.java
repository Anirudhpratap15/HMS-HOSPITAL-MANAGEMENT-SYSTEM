package com.coforge.hospital.service;

import java.sql.SQLException;

import com.coforge.hospital.bean.Specialization;

public interface SpecializationService {
	public void updateSepcialization() throws SQLException;
	public void deleteSepcialization() throws SQLException;
	public void addSpecialzation() throws SQLException;
	public void display();
	
	public Specialization getSpeciality();

}
