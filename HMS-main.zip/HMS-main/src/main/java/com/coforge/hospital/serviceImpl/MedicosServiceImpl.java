package com.coforge.hospital.serviceImpl;

import java.sql.SQLException;

import com.coforge.hospital.bean.Medicos;
import com.coforge.hospital.daoImpl.MedicosDaoImpl;
import com.coforge.hospital.service.MedicosService;

public class MedicosServiceImpl implements MedicosService {

	private MedicosDaoImpl impl = new MedicosDaoImpl();

	public void add(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException {
		impl.addMed(dService, pService);
	}

	public void delete() throws SQLException {
		impl.deleteMed();
	}

	public void update(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException {
		impl.updateMed(dService, pService);
	}

	public void display() {
		impl.display();
	}

	public Medicos getMedicos() {
		return impl.getMedicos();
	}
}
