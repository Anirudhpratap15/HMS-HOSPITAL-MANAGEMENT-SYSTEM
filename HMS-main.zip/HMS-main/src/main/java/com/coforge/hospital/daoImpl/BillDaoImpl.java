package com.coforge.hospital.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.coforge.hospital.bean.Bill;
import com.coforge.hospital.dao.BillDao;
import com.coforge.hospital.database.Database;
import com.coforge.hospital.serviceImpl.InsuranceServiceImpl;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;
import com.coforge.hospital.util.IdNotFound;

public class BillDaoImpl implements BillDao{

	static private List<Bill> bills = new ArrayList<Bill>();
	private Scanner sc = new Scanner(System.in);

	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	private final String addData = "INSERT INTO bill VALUES(?,?,?,?,?,?)";
	private final String retriveData = "SELECT * FROM bill WHERE isDeleted = false";
	private final String updateData = "UPDATE bill SET Bamt = ?, Itype = ?, Ino = ?, pid = ? WHERE Bid = ?";
	private final String deleteData = "UPDATE bill SET isDeleted = true WHERE Bid = ?";
	
	public BillDaoImpl() {
		bills = retrieveBill();
	}
	
	public void generateBill(InsuranceServiceImpl iService, PatientServiceImpl pService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(addData);

			System.out.print("Enter Bill ID : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			System.out.print("Enter Bill Amount : ");
			double amt = sc.nextDouble();
			pst.setDouble(2, amt);

			sc.nextLine();
			System.out.print("Enter Insurance Type : ");
			String inType = sc.nextLine();
			pst.setString(3, inType);

			pst.setInt(4, iService.getInsurance().getiNo());
			pst.setInt(5, pService.getPatient().getPid());
			pst.setBoolean(6, false);

			pst.executeUpdate();

			System.out.println("======================\n" + "Bill " + id + " Generated\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void updateBill(InsuranceServiceImpl iService, PatientServiceImpl pService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(updateData);

			System.out.print("Enter Bill ID : ");
			int id = sc.nextInt();
			pst.setInt(5, id);

			System.out.print("Enter Bill Amount : ");
			double amt = sc.nextDouble();
			pst.setDouble(1, amt);

			sc.nextLine();
			System.out.print("Enter Insurance Type : ");
			String inType = sc.nextLine();
			pst.setString(2, inType);

			pst.setInt(3, iService.getInsurance().getiNo());
			pst.setInt(4, pService.getPatient().getPid());

			pst.executeUpdate();

			System.out.println("======================\n" + "Bill " + id + " Updated\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public void deleteBill() throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(deleteData);

			System.out.print("Enter Bill ID : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			pst.executeUpdate();

			System.out.println("======================\n" + "Bill " + id + " Deleted\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<Bill> retrieveBill() {
		List<Bill> billList = new ArrayList<Bill>();
		try {
			con = Database.connect();
			pst = con.prepareStatement(retriveData);
			rs = pst.executeQuery();

			while (rs.next()) {
				billList.add(new Bill(rs.getInt(1), rs.getDouble(2), rs.getString(3),
						InsuranceDaoImpl.getInsurance(rs.getInt(4)), PatientDaoImpl.getPatient(rs.getInt(5))));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return billList;
	}

	public void display() {
		bills = retrieveBill();
		System.out.println("------------------------------------------------");
		for (Bill b : bills) {
			System.out.println("Bill ID : " + b.getbId());
			System.out.println("Bill Amount : " + b.getbAmt());
			System.out.println("IS Insuared : " + b.getInsuared());
			System.out.println("Insurance No : " + b.getInsurance().getiNo());
			System.out.println("Patient Name : " + b.getPatient().getPid() + " " + b.getPatient().getpName());
			System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		}
		System.out.println("------------------------------------------------");
		
	}

	public Bill getBill() {
		boolean findIt = true;
		do {
			int flag = 0;
			System.out.print("Enter Bill ID : ");
			int id = sc.nextInt();
			for (Bill d : bills) {
				if (d.getbId() == id) {
					flag = 1;
					findIt = false;
					return d;
				}
			}
			try {
				if (flag == 0) {
					throw new IdNotFound();
				}
			} catch (IdNotFound e) {
				System.out.println(e.toString());
			}
		} while (findIt);
		return null;
	}

	public static Bill getBill(int id) {
		for (Bill d : bills)
			if (d.getbId() == id)
				return d;
		return null;
	}
}
