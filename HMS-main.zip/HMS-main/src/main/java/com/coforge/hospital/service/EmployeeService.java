package com.coforge.hospital.service;

import java.sql.SQLException;

import com.coforge.hospital.bean.Employee;
import com.coforge.hospital.serviceImpl.DepartmentServiceImpl;

public interface EmployeeService {

	public void display();
	public void add(DepartmentServiceImpl dService) throws SQLException;
	public void update(DepartmentServiceImpl dService) throws SQLException;
	public void delete() throws SQLException;
	
	public Employee getEmployee();
}
