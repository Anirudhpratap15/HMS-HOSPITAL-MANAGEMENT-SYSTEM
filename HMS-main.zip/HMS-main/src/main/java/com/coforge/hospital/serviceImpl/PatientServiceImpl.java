package com.coforge.hospital.serviceImpl;

import java.sql.SQLException;

import com.coforge.hospital.bean.Patient;
import com.coforge.hospital.daoImpl.PatientDaoImpl;
import com.coforge.hospital.service.PatientService;
import com.coforge.hospital.serviceImpl.TestServiceImpl;

public class PatientServiceImpl implements PatientService{

	private PatientDaoImpl patientImpl;
	
	public  PatientServiceImpl() {
		patientImpl=new PatientDaoImpl();
	}

	public void display() {
		patientImpl.display();
	}

	public void add(DoctorServiceImpl dService, TestServiceImpl tService) throws SQLException {
		patientImpl.addPatient(dService, tService);
	}

	public void update(DoctorServiceImpl dService, TestServiceImpl tService) throws SQLException {
		patientImpl.updatePatient(dService, tService);
	}

	public void delete() throws SQLException {
		patientImpl.deletePatient();
	}

	public Patient getPatient() {
		return patientImpl.getPatient();
	}

}
