package com.coforge.hospital.dao;

import java.sql.SQLException;
import java.util.List;

import com.coforge.hospital.bean.Test;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;

/**
 * 
 * @author shipra
 *
 */

public interface TestDao {

	public void doTest(DoctorServiceImpl dService) throws SQLException;

	public void update(DoctorServiceImpl dService) throws SQLException;

	public void delete() throws SQLException;

	public List<Test> retrieveTest();

	public void display();

	public Test getReport();
}
