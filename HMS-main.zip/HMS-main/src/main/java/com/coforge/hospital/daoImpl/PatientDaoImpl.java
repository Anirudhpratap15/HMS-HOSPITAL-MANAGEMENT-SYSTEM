package com.coforge.hospital.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.coforge.hospital.bean.Doctor;
import com.coforge.hospital.bean.Patient;
import com.coforge.hospital.bean.Test;
import com.coforge.hospital.dao.PatientDao;
import com.coforge.hospital.database.Database;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;
import com.coforge.hospital.serviceImpl.TestServiceImpl;
import com.coforge.hospital.util.IdNotFound;


public class PatientDaoImpl implements PatientDao {

	static private List<Patient> patients = new ArrayList<Patient>();
	private Scanner sc = new Scanner(System.in);;

	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	private final String addData = "INSERT INTO patient VALUES(?,?,?,?,?,?,?,?)";
	private final String retriveData = "SELECT * FROM patient WHERE isDeleted = false";
	private final String updateData = "UPDATE patient SET Pname = ?, Pdob= ?, Paddress = ?, PmobileNo = ?, Did = ?, Tid = ? WHERE Pid = ?";
	private final String deleteData = "UPDATE patient SET isDeleted = true WHERE Pid = ?";

	public PatientDaoImpl() {
		patients = retrievePatients();

	}

	public void display() {
		patients = retrievePatients();
		System.out.println("-----------------------------------------------");
		for (Patient patient : patients) {
			System.out.println("patient ID 	: " + patient.getPid());
			System.out.println("patient name 	: " + patient.getpName());
			System.out.println("patient pno 	: " + patient.getpMobileNo());
			System.out.println("patient dob 	: " + patient.getpDob());
			System.out.println("patient address	: " + patient.getpAdd());
			System.out.println("test ID 	: " + patient.getTest().gettName());
			System.out.println("Doctor Name 	: " + patient.getDoc().getDoctorName());
			System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++");
		}
		System.out.println("------------------------------------------------");
	}

	public List<Patient> retrievePatients() {
		List<Patient> patList = new ArrayList<Patient>();
		try {
			con = Database.connect();
			pst = con.prepareStatement(retriveData);
			rs = pst.executeQuery();
			
			while(rs.next()) {
				Patient patient = new Patient();
				
				patient.setPid(rs.getInt(1));
				patient.setpName(rs.getString(2));
				patient.setpDob(rs.getString(3));
				patient.setpAdd(rs.getString(4));
				patient.setpMobileNo(rs.getLong(5));
				patient.setDoc(DoctorDaoImpl.getDoctor(rs.getInt(6)));
				patient.setTest(TestDaoImpl.getReport(rs.getInt(7)));
				
				patList.add(patient);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return patList;
	}

	public void addPatient(DoctorServiceImpl dService, TestServiceImpl tService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(addData);


			System.out.print("Enter Patient Id : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			sc.nextLine();
			System.out.print("Enter Patient name : ");
			String name = sc.nextLine();
			pst.setString(2, name);

			System.out.print("Enter Patient DOB : ");
			String dob = sc.nextLine();
			pst.setString(3, dob);

			System.out.print("Enter Patient Address : ");
			String address = sc.nextLine();
			pst.setString(4, address);

			System.out.print("Enter Patient Mobile No : ");
			long mNo = sc.nextLong();
			pst.setLong(5, mNo);

			Doctor doc = dService.getDoctor();
			pst.setInt(6, doc.getDoctorId());

			Test test = tService.getReport();
			pst.setInt(7, test.getTid());
			
			pst.setBoolean(8, false);

			pst.executeUpdate();

			System.out.println("======================\n" + "Patient " + id + " Saved\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void updatePatient(DoctorServiceImpl dService, TestServiceImpl tService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(updateData);
			
			System.out.print("Enter Patient Id : ");
			int id = sc.nextInt();
			pst.setInt(7, id);

			sc.nextLine();
			System.out.print("Enter Patient name : ");
			String name = sc.nextLine();
			pst.setString(1, name);

			System.out.print("Enter Patient DOB : ");
			String dob = sc.nextLine();
			pst.setString(2, dob);

			System.out.print("Enter Patient Address : ");
			String address = sc.nextLine();
			pst.setString(3, address);

			System.out.print("Enter Patient Mobile No : ");
			long mNo = sc.nextLong();
			pst.setLong(4, mNo);

			Doctor doc = dService.getDoctor();
			pst.setInt(5, doc.getDoctorId());

			Test test = tService.getReport();
			pst.setInt(6, test.getTid());
			
			pst.executeUpdate();
			
			System.out.println("======================\n" + "Patient " + id + " Updated\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void deletePatient() throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(deleteData);
			
			System.out.print("Enter Patient Id : ");
			int id = sc.nextInt();
			pst.setInt(1, id);
			
			pst.executeUpdate();
			
			System.out.println("======================\n" + "Patient " + id + " Deleted\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Patient getPatient() {
		boolean findIt = true;
		do {
			int flag = 0;
			System.out.print("Enter Patient ID : ");
			int id = sc.nextInt();
			for (Patient p : patients) {
				if (p.getPid() == id) {
					flag = 1;
					findIt = false;
					return p;
				}
			}
			try {
				if (flag == 0) {
					throw new IdNotFound();
				}
			} catch (IdNotFound e) {
				System.out.println(e.toString());
			}
		} while (findIt);
		return null;
	}

	public static Patient getPatient(int id) {
		for(Patient p : patients)
			if(p.getPid() == id)
				return p;
		return null;
	}
}
