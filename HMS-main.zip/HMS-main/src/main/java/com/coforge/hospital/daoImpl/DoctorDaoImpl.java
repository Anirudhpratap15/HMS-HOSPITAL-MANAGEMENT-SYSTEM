package com.coforge.hospital.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.coforge.hospital.bean.Department;
import com.coforge.hospital.bean.Doctor;
import com.coforge.hospital.bean.Specialization;
import com.coforge.hospital.dao.DoctorDao;
import com.coforge.hospital.database.Database;
import com.coforge.hospital.serviceImpl.DepartmentServiceImpl;
import com.coforge.hospital.serviceImpl.SpecializationServiceImpl;
import com.coforge.hospital.util.IdNotFound;

public class DoctorDaoImpl implements DoctorDao{

	static private List<Doctor> doctors = new ArrayList<Doctor>();

	Scanner sc = new Scanner(System.in);

	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	private final String addData = "INSERT INTO doctor VALUES(?,?,?,?,?,?,?)";
	private final String retrieveData = "SELECT * FROM doctor WHERE isDeleted = false";
	private final String updateData = "UPDATE doctor SET Dname = ?, Daddress = ?, DphoneNo = ?, Deptid = ?, Specid = ? WHERE Did = ?";
	private final String deleteData = "UPDATE doctor SET isDeleted = true WHERE Did = ?";
	
	public DoctorDaoImpl() {
		doctors = retrieveDoctors();
	}

	public void addDoctor(DepartmentServiceImpl departmentService, SpecializationServiceImpl specializationService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(addData);

			System.out.print("Enter doctor id : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			sc.nextLine();
			System.out.print("Enter doctor name : ");
			String name = sc.nextLine();
			pst.setString(2, name);

			System.out.print("Enter doctor Address : ");
			String address = sc.nextLine();
			pst.setString(3, address);

			System.out.print("Enter doctor phone no : ");
			long pno = sc.nextLong();
			pst.setLong(4, pno);

			Department dept = departmentService.getDept();
			pst.setInt(5, dept.getDeptId());


			Specialization spec = specializationService.getSpeciality();
			pst.setInt(6, spec.getSpecId());
			
			pst.setBoolean(7, false);

			pst.executeUpdate();

			System.out.println("======================\n" + "Doctor " + id + " Saved\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}


	public Doctor getDoctor() {
		boolean findIt = true;
		do {
		int flag = 0;
		System.out.print("Enter Doctor ID : ");
		int id = sc.nextInt();
		for (Doctor d : doctors) {
			if (d.getDoctorId() == id) {
				flag = 1;
				findIt = false;
				return d;
			}
		}
		try {
			if (flag == 0)
				throw new IdNotFound();
		} catch (IdNotFound e) {
			System.out.println(e.toString());
		}
		}while(findIt);
		return null;
	}

	public void updateDoctor(DepartmentServiceImpl departmentService, SpecializationServiceImpl specializationService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(updateData);

			System.out.print("Enter doctor id : ");
			int id = sc.nextInt();
			pst.setInt(6, id);

			sc.nextLine();
			System.out.print("Enter doctor name : ");
			String name = sc.nextLine();
			pst.setString(1, name);

			System.out.print("Enter doctor Address : ");
			String address = sc.nextLine();
			pst.setString(2, address);

			System.out.print("Enter doctor phone no : ");
			long pno = sc.nextLong();
			pst.setLong(3, pno);

			Department dept = departmentService.getDept();
			pst.setInt(4, dept.getDeptId());

			Specialization spec = specializationService.getSpeciality();
			pst.setInt(5, spec.getSpecId());

			pst.executeUpdate();

			System.out.println("======================\n" + "Doctor " + id + " update\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

	public void deleteDoctor() throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(deleteData);

			System.out.print("Enter doctor id : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			pst.executeUpdate();

			System.out.println("======================\n" + "Doctor " + id + " delete\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

	public List<Doctor> retrieveDoctors() {
		List<Doctor> docList = new ArrayList<Doctor>();
		try {
			con = Database.connect();
			pst = con.prepareStatement(retrieveData);
			rs = pst.executeQuery();

			while (rs.next()) {
				Doctor doc = new Doctor();

				doc.setDoctorId(rs.getInt(1));
				doc.setDoctorName(rs.getString(2));
				doc.setDoctorAddress(rs.getString(3));
				doc.setDoctorPhoneNO(rs.getLong(4));
				doc.setDepartment(DepartmentDaoImpl.getDepartment(rs.getInt(5)));
				doc.setSepcialization(SpecializationDaoImpl.getSpeciality(rs.getInt(6)));

				docList.add(doc);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return docList;
	}

	public void display() {
		doctors = retrieveDoctors();
		System.out.println("-------------------------------------------");
		for (Doctor doctor : doctors) {
			System.out.println("Doctor id       : " + doctor.getDoctorId());
			System.out.println("Doctor name     : " + doctor.getDoctorName());
			System.out.println("Doctor Phone no : " + doctor.getDoctorPhoneNO());
			System.out.println("Doctor Address  : " + doctor.getDoctorAddress());
			System.out.println("Speciality      : " + doctor.getSepcialization().getSpeciality());
			System.out.println("Department Name : " + doctor.getDepartment().getDeptName());
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++");
		}
		System.out.println("-------------------------------------------");		
	}

	public static Doctor getDoctor(int id) {
		for (Doctor d : doctors)
			if (d.getDoctorId() == id)
				return d;
		return null;
	}

}
