package com.coforge.hospital.dao;

import java.sql.SQLException;
import java.util.List;

import com.coforge.hospital.bean.Patient;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;
import com.coforge.hospital.serviceImpl.TestServiceImpl;

/**
 * 
 * @author Shipra
 *
 */

public interface PatientDao {
	public void display();

	public List<Patient> retrievePatients();

	public void addPatient(DoctorServiceImpl dService, TestServiceImpl tService) throws SQLException;

	public void updatePatient(DoctorServiceImpl dService, TestServiceImpl tService) throws SQLException;

	public void deletePatient() throws SQLException;

	public Patient getPatient();

}
