package com.coforge.hospital.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.coforge.hospital.bean.Insurance;
import com.coforge.hospital.dao.InsuranceDao;
import com.coforge.hospital.database.Database;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;
import com.coforge.hospital.util.IdNotFound;

public class InsuranceDaoImpl implements InsuranceDao {

	static private List<Insurance> insurances = new ArrayList<Insurance>();
	private Scanner sc = new Scanner(System.in);

	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	private final String addData = "INSERT INTO insurance VALUES(?,?,?,?,?)";
	private final String retriveData = "SELECT * FROM insurance WHERE isDeleted = false";
	private final String updateData = "UPDATE insurance SET Iamt = ?, Iexpiredate = ?, pid = ? WHERE Ino = ?";
	private final String deleteData = "update insurance SET isDeleted = true WHERE Ino = ?";

	public InsuranceDaoImpl() {
		insurances = retrieveInsurance();
	}

	public static Insurance getInsurance(int id) {
		for (Insurance i : insurances)
			if (i.getiNo() == id)
				return i;
		return null;
	}

	public void addInsurance(PatientServiceImpl pService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(addData);

			System.out.print("Enter Insurace ID : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			System.out.print("Enter Insurace Amount : ");
			double amt = sc.nextDouble();
			pst.setDouble(2, amt);

			sc.nextLine();
			System.out.print("Enter Insurace Expire Date : ");
			String expiryDate = sc.nextLine();
			pst.setString(3, expiryDate);

			pst.setInt(4, pService.getPatient().getPid());

			pst.setBoolean(5, false);

			pst.executeUpdate();

			System.out.println("======================\n" + "Insurance " + id + " Saved\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void updateInsurance(PatientServiceImpl pService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(updateData);

			System.out.print("Enter Insurace ID : ");
			int id = sc.nextInt();
			pst.setInt(4, id);

			System.out.print("Enter Insurace Amount : ");
			double amt = sc.nextDouble();
			pst.setDouble(1, amt);

			sc.nextLine();
			System.out.print("Enter Insurace Expire Date : ");
			String expiryDate = sc.nextLine();
			pst.setString(2, expiryDate);

			pst.setInt(3, pService.getPatient().getPid());

			pst.executeUpdate();

			System.out
					.println("======================\n" + "Insurance " + id + " Updated\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void deleteInsurance() throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(deleteData);

			System.out.print("Enter Insurace ID : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			pst.executeUpdate();

			System.out
					.println("======================\n" + "Insurance " + id + " deleted\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	
	public List<Insurance> retrieveInsurance() {
		List<Insurance> inList = new ArrayList<Insurance>();

		try {
			con = Database.connect();
			pst = con.prepareStatement(retriveData);
			rs = pst.executeQuery();

			while (rs.next()) {
				inList.add(new Insurance(rs.getInt(1), rs.getLong(2), rs.getString(3),
						PatientDaoImpl.getPatient(rs.getInt(4))));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return inList;
	}

	
	public Insurance getInsurance() {
		boolean findIt = true;
		do {
			int flag = 0;
			System.out.print("Enter Insurance ID : ");
			int id = sc.nextInt();
			for (Insurance d : insurances) {
				if (d.getiNo() == id) {
					flag = 1;
					findIt = false;
					return d;
				}
			}
			try {
				if (flag == 0) {
					throw new IdNotFound();
				}
			} catch (IdNotFound e) {
				System.out.println(e.toString());
			}
		} while (findIt);
		return null;
	}

	
	public void display() {
		insurances = retrieveInsurance();

		System.out.println("----------------------------------------------");
		for (Insurance in : insurances) {
			System.out.println("Insurance ID 		: " + in.getiNo());
			System.out.println("Insurance Amount	: " + in.getiAmt());
			System.out.println("Insurance Expires 	: " + in.getiExpiryDate());
			System.out.println("Patient ID 		: " + in.getPatient().getPid());
			System.out.println("Patient Name 		: " + in.getPatient().getpName());
			System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		}
		System.out.println("----------------------------------------------");
	}

}
