package com.coforge.hospital.bean;
/**
 * 
 * @author Rashi
 *
 */
public class Insurance {

	private int iNo;
	private double iAmt;
	private String iExpiryDate;
	
	private Patient patient;

	public Insurance(int iNo, double iAmt, String iExpiryDate, Patient patient) {
		super();
		this.iNo = iNo;
		this.iAmt = iAmt;
		this.iExpiryDate = iExpiryDate;
		this.patient = patient;
	}

	public int getiNo() {
		return iNo;
	}

	public void setiNo(int iNo) {
		this.iNo = iNo;
	}

	public double getiAmt() {
		return iAmt;
	}

	public void setiAmt(double iAmt) {
		this.iAmt = iAmt;
	}

	public String getiExpiryDate() {
		return iExpiryDate;
	}

	public void setiExpiryDate(String iExpiryDate) {
		this.iExpiryDate = iExpiryDate;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	
	
	
}
