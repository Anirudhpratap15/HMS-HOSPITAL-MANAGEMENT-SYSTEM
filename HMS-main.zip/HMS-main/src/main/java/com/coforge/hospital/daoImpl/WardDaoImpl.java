package com.coforge.hospital.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.coforge.hospital.bean.Doctor;
import com.coforge.hospital.bean.Patient;
import com.coforge.hospital.bean.Ward;
import com.coforge.hospital.dao.WardDao;
import com.coforge.hospital.database.Database;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;
import com.coforge.hospital.serviceImpl.PatientServiceImpl;
import com.coforge.hospital.util.IdNotFound;

public class WardDaoImpl implements WardDao{
	static private List<Ward> wards = new ArrayList<Ward>();
	private Scanner sc = new Scanner(System.in);

	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	private final String addData = "INSERT INTO ward VALUES(?,?,?,?,?)";
	private final String retriveData = "SELECT * FROM ward WHERE isDeleted = false";
	private final String updateData = "UPDATE ward SET Wname = ?, Pid = ?, Did = ? WHERE Wid = ?";
	private final String deleteData = "UPDATE ward SET isDeleted = true WHERE Wid = ?";
	
	public WardDaoImpl() {
		wards = retrieveWard();
	}
	
	public void addWard(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(addData);


			System.out.print("Enter Ward Id : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			sc.nextLine();
			System.out.print("Enter Ward Name : ");
			String name = sc.nextLine();
			pst.setString(2, name);

			Patient patient = pService.getPatient();
			pst.setInt(3, patient.getPid());

			Doctor doc = dService.getDoctor();
			pst.setInt(4, doc.getDoctorId());
			
			pst.setBoolean(5, false);
			pst.executeUpdate();

			System.out.println("======================\n" + "Ward " + id + " Saved\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void updateWard(DoctorServiceImpl dService, PatientServiceImpl pService) throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(updateData);
			
			System.out.print("Enter Ward Id : ");
			int id = sc.nextInt();
			pst.setInt(4, id);

			sc.nextLine();
			System.out.print("Enter Ward Name : ");
			String name = sc.nextLine();
			pst.setString(1, name);

			Patient patient = pService.getPatient();
			pst.setInt(2, patient.getPid());

			Doctor doc = dService.getDoctor();
			pst.setInt(3, doc.getDoctorId());

			pst.executeUpdate();
			
			System.out.println("======================\n" + "Ward " + id + " Updated\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void deleteWard() throws SQLException {
		try {
			con = Database.connect();
			con.setAutoCommit(false);
			pst = con.prepareStatement(deleteData);
			
			System.out.print("Enter Ward Id : ");
			int id = sc.nextInt();
			pst.setInt(1, id);

			pst.executeUpdate();
			
			System.out.println("======================\n" + "Ward " + id + " Deleted\n" + "======================");
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		} finally {
			try {
				con.commit();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<Ward> retrieveWard() {
		List<Ward> wardList = new ArrayList<Ward>();
		try {
			con = Database.connect();
			pst = con.prepareStatement(retriveData);
			rs = pst.executeQuery();

			while (rs.next()) {
				wardList.add(new Ward(rs.getInt(1), 
						rs.getString(2), 
						PatientDaoImpl.getPatient(rs.getInt(3)), 
						DoctorDaoImpl.getDoctor(rs.getInt(4))));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return wardList;
	}
	
	public void display() {
		wards = retrieveWard();
		System.out.println("-----------------------------------------------------");
		for (Ward ward : wards) {
			System.out.println("Ward ID : " + ward.getWid());
			System.out.println("Ward Name : " + ward.getWardName());
			System.out.println("Ward Doctor : " + ward.getDoctor().getDoctorName());
			System.out.println("Ward Patient : " + ward.getPatient().getpName());
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
		}
		System.out.println("-----------------------------------------------------");
	}
	
	public Ward getWard() {
		boolean findIt = true;
		do {
			int flag = 0;
			System.out.print("Enter Department ID : ");
			int id = sc.nextInt();
			for (Ward w : wards) {
				if (w.getWid() == id) {
					flag = 1;
					findIt = false;
					return w;
				}
			}
			try {
				if (flag == 0) {
					throw new IdNotFound();
				}
			} catch (IdNotFound e) {
				System.out.println(e.toString());
			}
		} while (findIt);
		return null;
	}
}
