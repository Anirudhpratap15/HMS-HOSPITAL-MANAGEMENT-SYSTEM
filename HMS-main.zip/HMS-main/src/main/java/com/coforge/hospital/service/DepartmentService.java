package com.coforge.hospital.service;

import java.sql.SQLException;

import com.coforge.hospital.bean.Department;

public interface DepartmentService {

	public void addDepartment() throws SQLException;
	public void deleteDepartment() throws SQLException;
	public void updateDepartment() throws SQLException;
	
	public void display();
	
	public Department getDept();
}
