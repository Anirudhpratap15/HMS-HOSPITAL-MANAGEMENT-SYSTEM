package com.coforge.hospital.dao;
/**
 * 
 * @author Ayush Gupta
 *
 */

import java.sql.SQLException;
import java.util.List;

import com.coforge.hospital.bean.Department;

public interface DepartmentDao {

	/**
	 * this method used for adding a new department
	 */
	public void addDepartment() throws SQLException;
	public void updateDepartment() throws SQLException;
	public void deleteDepartment() throws SQLException;
	public List<Department> retrieveDept();
	/**
	 * this method used for printing all department
	 */
	public void display();
	
	public Department getDepartment();
}
