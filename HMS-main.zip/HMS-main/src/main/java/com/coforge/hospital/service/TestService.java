package com.coforge.hospital.service;

import java.sql.SQLException;

import com.coforge.hospital.bean.Test;
import com.coforge.hospital.serviceImpl.DoctorServiceImpl;

public interface TestService {

	public void add(DoctorServiceImpl dService) throws SQLException;
	public void update(DoctorServiceImpl dService) throws SQLException;
	public void delete() throws SQLException;
	
	public Test getReport();
	public void display();
}
